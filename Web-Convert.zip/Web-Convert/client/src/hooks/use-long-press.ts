import { useState, useEffect, useRef, useCallback } from "react";

interface UseLongPressOptions {
  threshold?: number;
  onStart?: () => void;
  onFinish?: () => void;
  onCancel?: () => void;
}

interface LongPressHandlers {
  onMouseDown: () => void;
  onMouseUp: () => void;
  onMouseLeave: () => void;
  onTouchStart: () => void;
  onTouchEnd: () => void;
}

interface UseLongPressReturn {
  handlers: LongPressHandlers;
  isPressed: boolean;
  progress: number;
}

export function useLongPress(
  callback: () => void,
  options: UseLongPressOptions = {}
): UseLongPressReturn {
  const { threshold = 2000, onStart, onFinish, onCancel } = options;
  const [isPressed, setIsPressed] = useState(false);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  const clearTimers = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const start = useCallback(() => {
    setIsPressed(true);
    setProgress(0);
    startTimeRef.current = Date.now();
    onStart?.();

    intervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTimeRef.current;
      const newProgress = Math.min((elapsed / threshold) * 100, 100);
      setProgress(newProgress);
    }, 50);

    timerRef.current = setTimeout(() => {
      clearTimers();
      setIsPressed(false);
      setProgress(100);
      onFinish?.();
      callback();
    }, threshold);
  }, [callback, threshold, onStart, onFinish, clearTimers]);

  const cancel = useCallback(() => {
    if (isPressed) {
      clearTimers();
      setIsPressed(false);
      setProgress(0);
      onCancel?.();
    }
  }, [isPressed, clearTimers, onCancel]);

  useEffect(() => {
    return () => {
      clearTimers();
    };
  }, [clearTimers]);

  const handlers: LongPressHandlers = {
    onMouseDown: start,
    onMouseUp: cancel,
    onMouseLeave: cancel,
    onTouchStart: start,
    onTouchEnd: cancel,
  };

  return { handlers, isPressed, progress };
}
