import { useState, useEffect, useCallback } from "react";
import type { Language } from "@/lib/i18n";
import type { FamilyMember, Volunteer, FireHotspot, EmergencyReport, CachedMap } from "@shared/schema";

interface AppPreferences {
  bigText: boolean;
  colorBlind: boolean;
  voiceCmd: boolean;
}

interface UserProfile {
  name: string;
  phone: string;
}

interface AppState {
  mode: "citizen" | "afad";
  lang: Language;
  preferences: AppPreferences;
  profile: UserProfile;
  droneFeed: { id: number; label: string; thermal: boolean } | null;
  liveFireMap: boolean;
}

const getStoredPreferences = (): AppPreferences => {
  try {
    const stored = localStorage.getItem("app_prefs");
    if (stored) {
      return JSON.parse(stored);
    }
  } catch {}
  return { bigText: false, colorBlind: false, voiceCmd: false };
};

const getStoredProfile = (): UserProfile => {
  return {
    name: localStorage.getItem("hes_name") || "",
    phone: localStorage.getItem("hes_phone") || "",
  };
};

const getStoredLang = (): Language => {
  const stored = localStorage.getItem("hes_lang");
  if (stored === "tr" || stored === "ku" || stored === "en") {
    return stored;
  }
  return "tr";
};

const getStoredMode = (): "citizen" | "afad" => {
  const stored = localStorage.getItem("hes_mode");
  if (stored === "afad") return "afad";
  return "citizen";
};

export function useAppState() {
  const [mode, setMode] = useState<"citizen" | "afad">(getStoredMode);
  const [lang, setLang] = useState<Language>(getStoredLang);
  const [preferences, setPreferences] = useState<AppPreferences>(getStoredPreferences);
  const [profile, setProfile] = useState<UserProfile>(getStoredProfile);
  const [droneFeed, setDroneFeed] = useState<{ id: number; label: string; thermal: boolean } | null>(null);
  const [liveFireMap, setLiveFireMap] = useState(false);

  useEffect(() => {
    localStorage.setItem("app_prefs", JSON.stringify(preferences));
  }, [preferences]);

  useEffect(() => {
    localStorage.setItem("hes_lang", lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem("hes_mode", mode);
  }, [mode]);

  const saveProfile = useCallback((newProfile: UserProfile) => {
    setProfile(newProfile);
    localStorage.setItem("hes_name", newProfile.name);
    localStorage.setItem("hes_phone", newProfile.phone);
  }, []);

  const clearProfile = useCallback(() => {
    setProfile({ name: "", phone: "" });
    localStorage.removeItem("hes_name");
    localStorage.removeItem("hes_phone");
  }, []);

  const toggleMode = useCallback(() => {
    setMode((m) => (m === "citizen" ? "afad" : "citizen"));
  }, []);

  const toggleBigText = useCallback(() => {
    setPreferences((p) => ({ ...p, bigText: !p.bigText }));
  }, []);

  const toggleColorBlind = useCallback(() => {
    setPreferences((p) => ({ ...p, colorBlind: !p.colorBlind }));
  }, []);

  const toggleVoiceCmd = useCallback(() => {
    setPreferences((p) => ({ ...p, voiceCmd: !p.voiceCmd }));
  }, []);

  const toggleDroneFeed = useCallback(() => {
    setDroneFeed((d) => (d ? null : { id: Date.now(), label: "Drone-720p-feed", thermal: true }));
  }, []);

  const toggleLiveFireMap = useCallback(() => {
    setLiveFireMap((s) => !s);
  }, []);

  return {
    mode,
    lang,
    preferences,
    profile,
    droneFeed,
    liveFireMap,
    setLang,
    toggleMode,
    toggleBigText,
    toggleColorBlind,
    toggleVoiceCmd,
    saveProfile,
    clearProfile,
    toggleDroneFeed,
    toggleLiveFireMap,
  };
}
