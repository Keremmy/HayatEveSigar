import { Flame, MapPin, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { t, type Language } from "@/lib/i18n";
import { useLongPress } from "@/hooks/use-long-press";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface EmergencyButtonProps {
  lang: Language;
  profile: {
    name: string;
    phone: string;
  };
  onEmergencyReport: (data: {
    name: string;
    phone: string;
    latitude: number;
    longitude: number;
  }) => void;
}

export function EmergencyButton({
  lang,
  profile,
  onEmergencyReport,
}: EmergencyButtonProps) {
  const { toast } = useToast();

  const handleEmergency = () => {
    if (!profile.name || !profile.phone) {
      toast({
        title: t(lang, "enterNamePhone"),
        variant: "destructive",
      });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        onEmergencyReport({
          name: profile.name,
          phone: profile.phone,
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        });
        toast({
          title: t(lang, "emergencySent"),
          description: `${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`,
        });
      },
      (err) => {
        toast({
          title: t(lang, "locationError"),
          description: err.message,
          variant: "destructive",
        });
      }
    );
  };

  const { handlers, isPressed, progress } = useLongPress(handleEmergency, {
    threshold: 2000,
  });

  return (
    <Card className="border-destructive/50 bg-destructive/5">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Flame className="h-5 w-5 text-destructive" />
          {t(lang, "emergencyReport")}
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          {t(lang, "emergencyDesc")}
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        <button
          {...handlers}
          className={cn(
            "relative w-full min-h-[64px] rounded-lg font-semibold text-lg",
            "bg-destructive text-destructive-foreground",
            "flex items-center justify-center gap-2",
            "transition-all duration-150",
            "select-none touch-none",
            "shadow-lg",
            isPressed && "scale-[0.98] shadow-md"
          )}
          data-testid="button-emergency"
        >
          {isPressed ? (
            <>
              <Loader2 className="h-6 w-6 animate-spin" />
              {t(lang, "sending")}
            </>
          ) : (
            <>
              <Flame className="h-6 w-6" />
              {t(lang, "emergency")}
            </>
          )}
        </button>
        
        {isPressed && (
          <div className="space-y-1">
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-center text-muted-foreground">
              {t(lang, "holdToReport")}
            </p>
          </div>
        )}

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>{t(lang, "holdToReport")}</span>
        </div>
      </CardContent>
    </Card>
  );
}
