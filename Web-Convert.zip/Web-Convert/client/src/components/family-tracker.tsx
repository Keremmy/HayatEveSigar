import { Users, MapPin, Phone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { t, type Language } from "@/lib/i18n";
import type { FamilyMember } from "@shared/schema";

interface FamilyTrackerProps {
  lang: Language;
  family: FamilyMember[];
}

export function FamilyTracker({ lang, family }: FamilyTrackerProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Users className="h-5 w-5" />
          {t(lang, "familyLocations")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[160px]">
          {family.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <Users className="h-8 w-8 mb-2 opacity-50" />
              <p className="text-sm">{t(lang, "noFamily")}</p>
            </div>
          ) : (
            <div className="space-y-2">
              {family.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between gap-2 p-3 rounded-md bg-muted/50 border"
                  data-testid={`family-item-${member.id}`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-sm font-medium text-primary">
                        {member.label.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{member.label}</p>
                      {member.phone && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {member.phone}
                        </p>
                      )}
                    </div>
                  </div>
                  {member.latitude && member.longitude && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground shrink-0">
                      <MapPin className="h-3 w-3" />
                      <span>
                        {member.latitude.toFixed(3)}, {member.longitude.toFixed(3)}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
