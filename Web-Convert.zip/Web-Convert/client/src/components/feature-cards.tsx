import { Map, Users, Plane, Camera, MapPin, Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { t, type Language } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

interface FeatureCardsProps {
  lang: Language;
  offlineMapName: string | null;
  droneFeed: { id: number; label: string; thermal: boolean } | null;
  familyCount: number;
  onCacheMap: () => void;
  onAddFamily: () => void;
  onToggleDrone: () => void;
  onCheckCapacity: () => void;
}

export function FeatureCards({
  lang,
  offlineMapName,
  droneFeed,
  familyCount,
  onCacheMap,
  onAddFamily,
  onToggleDrone,
  onCheckCapacity,
}: FeatureCardsProps) {
  const { toast } = useToast();

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">{t(lang, "requiredFeatures")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between gap-3 p-3 rounded-lg border bg-card">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
              <Map className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="font-medium text-sm truncate">{t(lang, "offlineMap")}</p>
              <p className="text-xs text-muted-foreground truncate">
                {offlineMapName || t(lang, "noCache")}
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onCacheMap} data-testid="button-cache-map">
            {t(lang, "cacheMap")}
          </Button>
        </div>

        <div className="flex items-center justify-between gap-3 p-3 rounded-lg border bg-card">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="font-medium text-sm">{t(lang, "familyTracker")}</p>
              <p className="text-xs text-muted-foreground">
                {t(lang, "smsBackup")} {familyCount > 0 && `(${familyCount})`}
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onAddFamily} data-testid="button-add-family">
            <Plus className="h-4 w-4 mr-1" />
            {t(lang, "add")}
          </Button>
        </div>

        <div className="flex items-center justify-between gap-3 p-3 rounded-lg border bg-card">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
              <Plane className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="font-medium text-sm">{t(lang, "droneThermal")}</p>
              <p className="text-xs text-muted-foreground">
                {droneFeed ? t(lang, "thermalLive") : t(lang, "off")}
              </p>
            </div>
          </div>
          <Button
            variant={droneFeed ? "default" : "outline"}
            size="sm"
            onClick={onToggleDrone}
            data-testid="button-toggle-drone"
          >
            {droneFeed ? t(lang, "stop") : t(lang, "start")}
          </Button>
        </div>

        <div className="flex items-center justify-between gap-3 p-3 rounded-lg border bg-card">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
              <Camera className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="font-medium text-sm">{t(lang, "picnicCapacity")}</p>
              <p className="text-xs text-muted-foreground">{t(lang, "droneCount")}</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onCheckCapacity} data-testid="button-check-capacity">
            {t(lang, "check")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
