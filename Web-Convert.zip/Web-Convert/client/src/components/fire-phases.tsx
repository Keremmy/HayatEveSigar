import { 
  Shield, AlertTriangle, TreePine, 
  Map, MessageSquare, GraduationCap, Users, Landmark,
  Siren, Navigation, Home, Dog, Flame,
  BarChart3, Heart, FileText
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { t, type Language } from "@/lib/i18n";

interface FirePhasesProps {
  lang: Language;
  liveFireMap: boolean;
  onToggleLiveMap: () => void;
}

export function FirePhases({ lang, liveFireMap, onToggleLiveMap }: FirePhasesProps) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-green-600 dark:text-green-400" />
            {t(lang, "beforeFire")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" data-testid="button-risk-map">
              <Map className="mr-1 h-4 w-4" />
              {t(lang, "riskMap")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-citizen-report">
              <MessageSquare className="mr-1 h-4 w-4" />
              {t(lang, "citizenReport")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-training">
              <GraduationCap className="mr-1 h-4 w-4" />
              {t(lang, "microTraining")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-volunteer">
              <Users className="mr-1 h-4 w-4" />
              {t(lang, "volunteer")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-picnic-analysis">
              <Landmark className="mr-1 h-4 w-4" />
              {t(lang, "picnicAnalysis")}
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">{t(lang, "beforeGoal")}</p>
        </CardContent>
      </Card>

      <Card className="border-destructive/30">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            {t(lang, "duringFire")}
            {liveFireMap && (
              <Badge variant="destructive" className="ml-2 animate-pulse">
                LIVE
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" data-testid="button-instant-alert">
              <Siren className="mr-1 h-4 w-4" />
              {t(lang, "instantAlert")}
            </Button>
            <Button 
              variant={liveFireMap ? "default" : "outline"} 
              size="sm" 
              onClick={onToggleLiveMap}
              data-testid="button-live-fire-map"
            >
              <Flame className="mr-1 h-4 w-4" />
              {t(lang, "liveFireMap")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-evac-route">
              <Navigation className="mr-1 h-4 w-4" />
              {t(lang, "evacRoute")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-shelters">
              <Home className="mr-1 h-4 w-4" />
              {t(lang, "shelters")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-animal-rescue">
              <Dog className="mr-1 h-4 w-4" />
              {t(lang, "animalRescue")}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <TreePine className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            {t(lang, "afterFire")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" data-testid="button-burned-area">
              <BarChart3 className="mr-1 h-4 w-4" />
              {t(lang, "burnedArea")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-tree-donation">
              <TreePine className="mr-1 h-4 w-4" />
              {t(lang, "treeDonation")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-psych-support">
              <Heart className="mr-1 h-4 w-4" />
              {t(lang, "psychSupport")}
            </Button>
            <Button variant="outline" size="sm" data-testid="button-fire-report">
              <FileText className="mr-1 h-4 w-4" />
              {t(lang, "fireReport")}
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">{t(lang, "afterGoal")}</p>
        </CardContent>
      </Card>
    </div>
  );
}
