import { Plane, Thermometer, Route, Scan } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { t, type Language } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

interface AdvancedToolsProps {
  lang: Language;
  droneFeed: { id: number; label: string; thermal: boolean } | null;
}

export function AdvancedTools({ lang, droneFeed }: AdvancedToolsProps) {
  const { toast } = useToast();

  const handleDamageDetect = () => {
    toast({
      title: t(lang, "damageDetectionStarted"),
    });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">{t(lang, "advancedTools")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-center gap-2">
            <Plane className="h-4 w-4 shrink-0" />
            <span>{t(lang, "drone720p")}</span>
            {droneFeed && (
              <span className="ml-auto text-xs text-green-600 dark:text-green-400">
                Active
              </span>
            )}
          </li>
          <li className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 shrink-0" />
            <span>{t(lang, "thermalContours")}</span>
          </li>
          <li className="flex items-center gap-2">
            <Route className="h-4 w-4 shrink-0" />
            <span>{t(lang, "escapeCorridors")}</span>
          </li>
        </ul>

        <Button 
          onClick={handleDamageDetect} 
          className="w-full"
          data-testid="button-damage-detect"
        >
          <Scan className="mr-2 h-4 w-4" />
          {t(lang, "damageDetect")}
        </Button>
      </CardContent>
    </Card>
  );
}
