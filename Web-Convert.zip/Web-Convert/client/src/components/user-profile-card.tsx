import { useState, useEffect } from "react";
import { User, Phone, Save, LogOut } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { t, type Language } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";

interface UserProfileCardProps {
  lang: Language;
  profile: {
    name: string;
    phone: string;
  };
  onSave: (profile: { name: string; phone: string }) => void;
  onClear: () => void;
}

export function UserProfileCard({
  lang,
  profile,
  onSave,
  onClear,
}: UserProfileCardProps) {
  const { toast } = useToast();
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone);

  useEffect(() => {
    setName(profile.name);
    setPhone(profile.phone);
  }, [profile]);

  const handleSave = () => {
    if (!name.trim() || !phone.trim()) {
      toast({
        title: t(lang, "enterNamePhone"),
        variant: "destructive",
      });
      return;
    }
    onSave({ name: name.trim(), phone: phone.trim() });
    toast({
      title: t(lang, "profileSaved"),
    });
  };

  const handleLogout = () => {
    setName("");
    setPhone("");
    onClear();
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <User className="h-5 w-5" />
          {t(lang, "signIn")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="user-name" className="text-sm text-muted-foreground">
            {t(lang, "name")}
          </Label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="user-name"
              placeholder={t(lang, "name")}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="pl-10"
              data-testid="input-name"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="user-phone" className="text-sm text-muted-foreground">
            {t(lang, "phone")}
          </Label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="user-phone"
              placeholder={t(lang, "phone")}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="pl-10"
              data-testid="input-phone"
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={handleSave} className="flex-1" data-testid="button-save-profile">
            <Save className="mr-2 h-4 w-4" />
            {t(lang, "save")}
          </Button>
          <Button variant="outline" onClick={handleLogout} data-testid="button-logout">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
