import { Users, UserPlus, QrCode } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { t, type Language } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import type { Volunteer } from "@shared/schema";

interface VolunteerCardProps {
  lang: Language;
  volunteers: Volunteer[];
  profile: { name: string; phone: string };
  onJoin: () => void;
}

export function VolunteerCard({
  lang,
  volunteers,
  profile,
  onJoin,
}: VolunteerCardProps) {
  const { toast } = useToast();

  const handleGetQR = () => {
    navigator.clipboard?.writeText("QR_CODE_DEMO");
    toast({
      title: t(lang, "qrCopied"),
    });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Users className="h-5 w-5" />
          {t(lang, "volunteerNetwork")}
        </CardTitle>
        <p className="text-sm text-muted-foreground">{t(lang, "volunteerDesc")}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-2">
          <Button onClick={onJoin} className="flex-1" data-testid="button-join-volunteer">
            <UserPlus className="mr-2 h-4 w-4" />
            {t(lang, "join")}
          </Button>
          <Button variant="outline" onClick={handleGetQR} data-testid="button-get-qr">
            <QrCode className="h-4 w-4" />
          </Button>
        </div>

        <ScrollArea className="h-[120px]">
          {volunteers.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              {t(lang, "noVolunteers")}
            </p>
          ) : (
            <div className="space-y-2">
              {volunteers.map((v) => (
                <div
                  key={v.id}
                  className="flex items-center justify-between gap-2 p-2 rounded-md bg-muted/50"
                  data-testid={`volunteer-item-${v.id}`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-xs font-medium text-primary">
                        {v.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span className="text-sm font-medium truncate">{v.name}</span>
                  </div>
                  <Badge variant="secondary" className="shrink-0">
                    {v.role}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
