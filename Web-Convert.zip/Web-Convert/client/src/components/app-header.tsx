import { Flame, User, Shield, Languages, Type, Eye, Mic } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ThemeToggle } from "@/components/theme-toggle";
import { LANGS, t, type Language } from "@/lib/i18n";

interface AppHeaderProps {
  mode: "citizen" | "afad";
  lang: Language;
  preferences: {
    bigText: boolean;
    colorBlind: boolean;
    voiceCmd: boolean;
  };
  onLangChange: (lang: Language) => void;
  onToggleMode: () => void;
  onToggleBigText: () => void;
  onToggleColorBlind: () => void;
  onToggleVoiceCmd: () => void;
}

export function AppHeader({
  mode,
  lang,
  preferences,
  onLangChange,
  onToggleMode,
  onToggleBigText,
  onToggleColorBlind,
  onToggleVoiceCmd,
}: AppHeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive text-destructive-foreground">
              <Flame className="h-6 w-6" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-bold leading-tight" data-testid="text-app-title">
                {t(lang, "appTitle")}
              </h1>
              <div className="flex items-center gap-2">
                <Badge 
                  variant={mode === "citizen" ? "secondary" : "default"}
                  className="text-xs"
                  data-testid="badge-mode"
                >
                  {mode === "citizen" ? (
                    <User className="mr-1 h-3 w-3" />
                  ) : (
                    <Shield className="mr-1 h-3 w-3" />
                  )}
                  {mode === "citizen" ? t(lang, "citizenMode") : t(lang, "afadMode")}
                </Badge>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            <Select value={lang} onValueChange={(v) => onLangChange(v as Language)}>
              <SelectTrigger className="w-[120px]" data-testid="select-language">
                <Languages className="mr-2 h-4 w-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(LANGS).map(([key, value]) => (
                  <SelectItem key={key} value={key} data-testid={`option-lang-${key}`}>
                    {value}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant={mode === "afad" ? "default" : "outline"}
              size="sm"
              onClick={onToggleMode}
              data-testid="button-toggle-mode"
            >
              {mode === "citizen" ? (
                <>
                  <Shield className="mr-1 h-4 w-4" />
                  <span className="hidden sm:inline">{t(lang, "switchToAfad")}</span>
                </>
              ) : (
                <>
                  <User className="mr-1 h-4 w-4" />
                  <span className="hidden sm:inline">{t(lang, "switchToCitizen")}</span>
                </>
              )}
            </Button>

            <div className="hidden md:flex items-center gap-1">
              <Button
                variant={preferences.bigText ? "default" : "ghost"}
                size="icon"
                onClick={onToggleBigText}
                data-testid="button-toggle-bigtext"
                title={preferences.bigText ? t(lang, "normalText") : t(lang, "bigText")}
              >
                <Type className="h-4 w-4" />
              </Button>

              <Button
                variant={preferences.colorBlind ? "default" : "ghost"}
                size="icon"
                onClick={onToggleColorBlind}
                data-testid="button-toggle-colorblind"
                title={preferences.colorBlind ? t(lang, "colorNormal") : t(lang, "colorBlind")}
              >
                <Eye className="h-4 w-4" />
              </Button>

              <Button
                variant={preferences.voiceCmd ? "default" : "ghost"}
                size="icon"
                onClick={onToggleVoiceCmd}
                data-testid="button-toggle-voice"
                title={t(lang, "voiceCommands")}
              >
                <Mic className="h-4 w-4" />
              </Button>
            </div>

            <ThemeToggle />
          </div>
        </div>
      </div>
    </header>
  );
}
