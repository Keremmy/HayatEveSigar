import { Flame, MapPin, Activity, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { t, type Language } from "@/lib/i18n";
import type { FireHotspot } from "@shared/schema";

interface HotspotMapProps {
  lang: Language;
  hotspots: FireHotspot[];
  liveFireMap: boolean;
}

function getIntensityColor(intensity: number): string {
  if (intensity >= 0.8) return "bg-red-500";
  if (intensity >= 0.6) return "bg-orange-500";
  if (intensity >= 0.4) return "bg-yellow-500";
  return "bg-green-500";
}

function getIntensityLabel(intensity: number, lang: Language): string {
  if (intensity >= 0.8) return lang === "tr" ? "Kritik" : lang === "ku" ? "Krîtîk" : "Critical";
  if (intensity >= 0.6) return lang === "tr" ? "Yüksek" : lang === "ku" ? "Bilind" : "High";
  if (intensity >= 0.4) return lang === "tr" ? "Orta" : lang === "ku" ? "Navîn" : "Medium";
  return lang === "tr" ? "Düşük" : lang === "ku" ? "Nizm" : "Low";
}

export function HotspotMap({ lang, hotspots, liveFireMap }: HotspotMapProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            {t(lang, "firmsHotspots")}
          </div>
          {liveFireMap && (
            <Badge variant="destructive" className="animate-pulse">
              <span className="mr-1 h-2 w-2 rounded-full bg-white inline-block animate-ping" />
              LIVE
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative rounded-lg border bg-muted/30 overflow-hidden">
          <div 
            className="h-[260px] relative"
            style={{
              background: `
                linear-gradient(180deg, 
                  hsl(var(--muted)) 0%, 
                  hsl(var(--muted) / 0.5) 100%
                )
              `,
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center p-4">
                <MapPin className="h-12 w-12 mx-auto mb-2 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground">
                  {liveFireMap ? t(lang, "liveSpread") : t(lang, "mapIdle")}
                </p>
              </div>
            </div>

            {hotspots.map((hotspot, index) => (
              <div
                key={hotspot.id}
                className="absolute flex items-center justify-center"
                style={{
                  left: `${20 + (index * 25) % 60}%`,
                  top: `${20 + (index * 20) % 50}%`,
                }}
                data-testid={`hotspot-marker-${hotspot.id}`}
              >
                <div className={`relative`}>
                  <div 
                    className={`h-4 w-4 rounded-full ${getIntensityColor(hotspot.intensity)} ${liveFireMap ? 'animate-pulse' : ''}`}
                  />
                  {hotspot.intensity >= 0.7 && (
                    <div 
                      className={`absolute inset-0 h-4 w-4 rounded-full ${getIntensityColor(hotspot.intensity)} animate-ping opacity-75`}
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <ScrollArea className="h-[140px] mt-4">
          {hotspots.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <AlertCircle className="h-8 w-8 mb-2" />
              <p className="text-sm">{t(lang, "activeHotspots")}: 0</p>
            </div>
          ) : (
            <div className="space-y-2">
              {hotspots.map((hotspot) => (
                <div
                  key={hotspot.id}
                  className="flex items-center justify-between gap-2 p-3 rounded-md bg-muted/50 border"
                  data-testid={`hotspot-item-${hotspot.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`h-3 w-3 rounded-full ${getIntensityColor(hotspot.intensity)}`} />
                    <div>
                      <p className="text-sm font-medium">
                        #{hotspot.id.slice(0, 8)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {hotspot.latitude.toFixed(4)}, {hotspot.longitude.toFixed(4)}
                      </p>
                    </div>
                  </div>
                  <Badge 
                    variant={hotspot.intensity >= 0.7 ? "destructive" : "secondary"}
                    className="shrink-0"
                  >
                    {getIntensityLabel(hotspot.intensity, lang)}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
