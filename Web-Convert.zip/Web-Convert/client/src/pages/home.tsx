import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppHeader } from "@/components/app-header";
import { UserProfileCard } from "@/components/user-profile-card";
import { EmergencyButton } from "@/components/emergency-button";
import { FeatureCards } from "@/components/feature-cards";
import { VolunteerCard } from "@/components/volunteer-card";
import { FirePhases } from "@/components/fire-phases";
import { HotspotMap } from "@/components/hotspot-map";
import { FamilyTracker } from "@/components/family-tracker";
import { AdvancedTools } from "@/components/advanced-tools";
import { useAppState } from "@/hooks/use-app-state";
import { useToast } from "@/hooks/use-toast";
import { t } from "@/lib/i18n";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { FireHotspot, Volunteer, FamilyMember, EmergencyReport, CachedMap } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const {
    mode,
    lang,
    preferences,
    profile,
    droneFeed,
    liveFireMap,
    setLang,
    toggleMode,
    toggleBigText,
    toggleColorBlind,
    toggleVoiceCmd,
    saveProfile,
    clearProfile,
    toggleDroneFeed,
    toggleLiveFireMap,
  } = useAppState();

  const [cachedMapName, setCachedMapName] = useState<string | null>(() => {
    try {
      const stored = localStorage.getItem("offline_map");
      if (stored) {
        const parsed = JSON.parse(stored);
        return parsed?.name || null;
      }
    } catch {}
    return null;
  });

  const { data: hotspots = [] } = useQuery<FireHotspot[]>({
    queryKey: ["/api/hotspots"],
  });

  const { data: volunteers = [] } = useQuery<Volunteer[]>({
    queryKey: ["/api/volunteers"],
  });

  const { data: familyMembers = [] } = useQuery<FamilyMember[]>({
    queryKey: ["/api/family"],
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: {
      reporterName: string;
      reporterPhone: string;
      latitude: number;
      longitude: number;
      severity?: string;
      description?: string;
    }) => {
      return apiRequest("POST", "/api/reports", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
    },
  });

  const createVolunteerMutation = useMutation({
    mutationFn: async (data: { name: string; phone: string; role?: string }) => {
      return apiRequest("POST", "/api/volunteers", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/volunteers"] });
      toast({ title: t(lang, "volunteerRegistered") });
    },
  });

  const addFamilyMutation = useMutation({
    mutationFn: async (data: { label: string; latitude?: number; longitude?: number }) => {
      return apiRequest("POST", "/api/family", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/family"] });
    },
  });

  const handleEmergencyReport = (data: {
    name: string;
    phone: string;
    latitude: number;
    longitude: number;
  }) => {
    createReportMutation.mutate({
      reporterName: data.name,
      reporterPhone: data.phone,
      latitude: data.latitude,
      longitude: data.longitude,
      severity: "high",
    });
  };

  const handleJoinVolunteer = () => {
    if (!profile.name || !profile.phone) {
      toast({
        title: t(lang, "enterNamePhone"),
        variant: "destructive",
      });
      return;
    }
    createVolunteerMutation.mutate({
      name: profile.name,
      phone: profile.phone,
      role: "Patrol",
    });
  };

  const handleAddFamily = () => {
    const memberNumber = familyMembers.length + 1;
    const label = `${t(lang, "member")} ${memberNumber}`;
    
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        addFamilyMutation.mutate({
          label,
          latitude: pos.coords.latitude + (Math.random() - 0.5) * 0.02,
          longitude: pos.coords.longitude + (Math.random() - 0.5) * 0.02,
        });
      },
      () => {
        addFamilyMutation.mutate({
          label,
          latitude: 37.0 + Math.random() * 0.02,
          longitude: 38.0 + Math.random() * 0.02,
        });
      }
    );
  };

  const handleCacheMap = () => {
    const mapName = `Cached map ${new Date().toLocaleString()}`;
    localStorage.setItem("offline_map", JSON.stringify({ name: mapName, data: {} }));
    setCachedMapName(mapName);
    toast({ title: t(lang, "cacheMap") });
  };

  const handleCheckCapacity = () => {
    toast({ title: t(lang, "areaFullAlert") });
  };

  const accessibilityClasses = [
    "min-h-screen bg-background",
    preferences.bigText ? "big-text-mode" : "",
    preferences.colorBlind ? "color-blind-mode" : "",
  ].filter(Boolean).join(" ");

  return (
    <div className={accessibilityClasses}>
      <AppHeader
        mode={mode}
        lang={lang}
        preferences={preferences}
        onLangChange={setLang}
        onToggleMode={toggleMode}
        onToggleBigText={toggleBigText}
        onToggleColorBlind={toggleColorBlind}
        onToggleVoiceCmd={toggleVoiceCmd}
      />

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-[320px_1fr] gap-6">
          <aside className="space-y-4">
            <UserProfileCard
              lang={lang}
              profile={profile}
              onSave={saveProfile}
              onClear={clearProfile}
            />

            <EmergencyButton
              lang={lang}
              profile={profile}
              onEmergencyReport={handleEmergencyReport}
            />

            <FeatureCards
              lang={lang}
              offlineMapName={cachedMapName}
              droneFeed={droneFeed}
              familyCount={familyMembers.length}
              onCacheMap={handleCacheMap}
              onAddFamily={handleAddFamily}
              onToggleDrone={toggleDroneFeed}
              onCheckCapacity={handleCheckCapacity}
            />

            <VolunteerCard
              lang={lang}
              volunteers={volunteers}
              profile={profile}
              onJoin={handleJoinVolunteer}
            />
          </aside>

          <div className="space-y-4">
            <FirePhases
              lang={lang}
              liveFireMap={liveFireMap}
              onToggleLiveMap={toggleLiveFireMap}
            />

            <HotspotMap
              lang={lang}
              hotspots={hotspots}
              liveFireMap={liveFireMap}
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <FamilyTracker lang={lang} family={familyMembers} />
              <AdvancedTools lang={lang} droneFeed={droneFeed} />
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-4 mt-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          {t(lang, "footer")}
        </div>
      </footer>
    </div>
  );
}
