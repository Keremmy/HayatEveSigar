import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, real, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  mode: text("mode").notNull().default("citizen"),
  lang: text("lang").notNull().default("tr"),
  bigText: boolean("big_text").notNull().default(false),
  colorBlind: boolean("color_blind").notNull().default(false),
  voiceCmd: boolean("voice_cmd").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emergencyReports = pgTable("emergency_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  reporterName: text("reporter_name").notNull(),
  reporterPhone: text("reporter_phone").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  description: text("description"),
  severity: text("severity").notNull().default("medium"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fireHotspots = pgTable("fire_hotspots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  intensity: real("intensity").notNull(),
  source: text("source").notNull().default("FIRMS"),
  detectedAt: timestamp("detected_at").defaultNow(),
  isActive: boolean("is_active").notNull().default(true),
});

export const volunteers = pgTable("volunteers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  role: text("role").notNull().default("Patrol"),
  region: text("region"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const familyMembers = pgTable("family_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  label: text("label").notNull(),
  phone: text("phone"),
  latitude: real("latitude"),
  longitude: real("longitude"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const cachedMaps = pgTable("cached_maps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  name: text("name").notNull(),
  region: text("region"),
  centerLat: real("center_lat"),
  centerLon: real("center_lon"),
  zoomLevel: integer("zoom_level"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  emergencyReports: many(emergencyReports),
  volunteers: many(volunteers),
  familyMembers: many(familyMembers),
  cachedMaps: many(cachedMaps),
}));

export const emergencyReportsRelations = relations(emergencyReports, ({ one }) => ({
  user: one(users, {
    fields: [emergencyReports.userId],
    references: [users.id],
  }),
}));

export const volunteersRelations = relations(volunteers, ({ one }) => ({
  user: one(users, {
    fields: [volunteers.userId],
    references: [users.id],
  }),
}));

export const familyMembersRelations = relations(familyMembers, ({ one }) => ({
  user: one(users, {
    fields: [familyMembers.userId],
    references: [users.id],
  }),
}));

export const cachedMapsRelations = relations(cachedMaps, ({ one }) => ({
  user: one(users, {
    fields: [cachedMaps.userId],
    references: [users.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertEmergencyReportSchema = createInsertSchema(emergencyReports).omit({
  id: true,
  createdAt: true,
});

export const insertFireHotspotSchema = createInsertSchema(fireHotspots).omit({
  id: true,
  detectedAt: true,
});

export const insertVolunteerSchema = createInsertSchema(volunteers).omit({
  id: true,
  createdAt: true,
});

export const insertFamilyMemberSchema = createInsertSchema(familyMembers).omit({
  id: true,
  lastUpdated: true,
});

export const insertCachedMapSchema = createInsertSchema(cachedMaps).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertEmergencyReport = z.infer<typeof insertEmergencyReportSchema>;
export type EmergencyReport = typeof emergencyReports.$inferSelect;
export type InsertFireHotspot = z.infer<typeof insertFireHotspotSchema>;
export type FireHotspot = typeof fireHotspots.$inferSelect;
export type InsertVolunteer = z.infer<typeof insertVolunteerSchema>;
export type Volunteer = typeof volunteers.$inferSelect;
export type InsertFamilyMember = z.infer<typeof insertFamilyMemberSchema>;
export type FamilyMember = typeof familyMembers.$inferSelect;
export type InsertCachedMap = z.infer<typeof insertCachedMapSchema>;
export type CachedMap = typeof cachedMaps.$inferSelect;
