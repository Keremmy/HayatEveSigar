# Design Guidelines: Orman Eve Sığar - Forest Fire Emergency Response Platform

## Design Approach

**System-Based Approach**: Material Design principles adapted for emergency/safety applications, emphasizing clarity, quick actions, and mobile-first usability. This is a utility-focused platform where reliability and speed are paramount.

**Key Principles:**
- Immediate clarity and actionability
- High contrast for outdoor visibility
- Large touch targets for emergency situations
- Minimal cognitive load during crisis
- Accessibility-first design

---

## Typography

**Font Family:** 
- Primary: Inter (via Google Fonts CDN)
- Fallback: system-ui, -apple-system, sans-serif

**Hierarchy:**
- H1 (App Title): 28px/32px, font-weight 700
- H2 (Section Headers): 20px/24px, font-weight 600
- H3 (Card Titles): 16px/20px, font-weight 600
- Body Text: 14px/20px, font-weight 400
- Small/Meta Text: 12px/16px, font-weight 400
- Button Text: 14px/16px, font-weight 500

**Accessibility Modes:**
- Large Text Mode: Scale all sizes by 1.3x
- Maintain 4.5:1 contrast ratio minimum

---

## Layout System

**Tailwind Spacing Units:** Standardize on 2, 4, 6, 8, 12, 16 units
- Compact spacing: p-2, gap-2
- Standard spacing: p-4, gap-4, mb-4
- Section spacing: py-8, px-4
- Card padding: p-4 to p-6
- Grid gaps: gap-4

**Grid Structure:**
- Mobile (default): Single column, full-width
- Tablet (md:): Two-column sidebar layout (320px sidebar + flex main)
- Desktop (lg:): max-w-7xl container, maintain sidebar layout

**Container Strategy:**
- Max-width: max-w-7xl
- Side padding: px-4 mobile, px-6 desktop
- Grid template: `grid-cols-1 md:grid-cols-[320px_1fr]`

---

## Component Library

### Navigation & Header
- Fixed top header with app branding, language selector, and mode toggle
- Compact header height: h-16
- Flex layout with space-between alignment
- Icons from Heroicons (via CDN)

### Emergency Action Button
- Large, prominent button (min-height: 64px)
- Full-width on mobile, fixed position option
- Clear visual feedback during long-press (progress indicator)
- High contrast background with white text
- Shadow: shadow-lg for emphasis

### Feature Cards
- White background with rounded-xl borders
- Subtle shadow: shadow-md
- Flex layout with space-between for icon + content + action
- Icon size: 24x24px
- Consistent padding: p-4

### Sidebar (User Profile & Quick Actions)
- Fixed width: 320px on desktop
- Stack vertically on mobile
- Grouped sections with cards
- Input fields: rounded-lg, border, px-3 py-2
- Button groups: flex gap-2

### Data Display Panels
- Map container: Full-width, min-height: 400px, rounded-lg
- Alert list: Stacked cards with timestamp, severity indicator
- Volunteer roster: Grid or list with avatar placeholders, name, role
- Family tracker: List with location pins, status indicators

### Forms
- Input fields: Full-width, rounded-lg, border, h-10
- Labels: mb-1, font-medium
- Button groups: flex gap-2, justify-end
- Error states: Red border, small text below

### Status Indicators
- Severity levels: Small badges (rounded-full, px-2 py-1, text-xs)
- Live status: Pulsing dot indicator for active feeds
- Connection status: Fixed bottom-right corner indicator

### Modal Overlays
- Full-screen on mobile, centered card on desktop
- Backdrop: Semi-transparent overlay
- Close button: Top-right corner
- Max-width: max-w-lg

---

## Interaction Patterns

**Emergency Actions:**
- Long-press visual feedback: Scale transform and progress ring
- Confirmation dialogs: Clear yes/no actions
- Toast notifications: Fixed top-center, auto-dismiss

**Map Interactions:**
- Pinch-to-zoom enabled
- Tap markers for details
- Offline mode indicator overlay

**Accessibility:**
- Focus states: 2px outline, high contrast
- Skip-to-content links
- ARIA labels on icon-only buttons
- Keyboard navigation throughout

---

## Mobile-First Considerations

- Touch targets: Minimum 44x44px
- Bottom sheet pattern for quick actions
- Swipe gestures for switching between views
- Sticky emergency button (floating action button pattern)
- Optimized for one-handed use

---

## Images

**Hero Section:** NO large hero image - this is a functional emergency app, not a marketing site. Lead directly with the emergency action button and core features.

**Map Backgrounds:**
- Integrate map tiles (OpenStreetMap or similar via CDN)
- Satellite/terrain toggle option
- Fire hotspot overlays

**Icons:**
- Heroicons for all UI elements (solid variant for primary actions, outline for secondary)
- Fire emoji (🔥) for emergency button
- Weather/status icons for risk indicators

**Placeholder Assets:**
- User avatars: Circle, 40x40px, initials on gray background
- Drone feed: 16:9 aspect ratio video placeholder
- QR codes: Generated via library, 200x200px

---

## Animation Guidelines

**Minimal Animations Only:**
- Emergency button long-press: Progress indicator fill
- Toast notifications: Slide-in from top (200ms)
- Modal open/close: Fade backdrop + scale content (150ms)
- Status changes: Subtle pulse for live indicators

**No Decorative Animations** - maintain focus on functionality and quick response times.