import { 
  users, 
  emergencyReports, 
  fireHotspots, 
  volunteers, 
  familyMembers, 
  cachedMaps,
  type User, 
  type InsertUser,
  type EmergencyReport,
  type InsertEmergencyReport,
  type FireHotspot,
  type InsertFireHotspot,
  type Volunteer,
  type InsertVolunteer,
  type FamilyMember,
  type InsertFamilyMember,
  type CachedMap,
  type InsertCachedMap,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getEmergencyReports(): Promise<EmergencyReport[]>;
  getEmergencyReport(id: string): Promise<EmergencyReport | undefined>;
  createEmergencyReport(report: InsertEmergencyReport): Promise<EmergencyReport>;
  updateEmergencyReportStatus(id: string, status: string): Promise<EmergencyReport | undefined>;
  
  getFireHotspots(): Promise<FireHotspot[]>;
  getActiveFireHotspots(): Promise<FireHotspot[]>;
  createFireHotspot(hotspot: InsertFireHotspot): Promise<FireHotspot>;
  
  getVolunteers(): Promise<Volunteer[]>;
  getActiveVolunteers(): Promise<Volunteer[]>;
  createVolunteer(volunteer: InsertVolunteer): Promise<Volunteer>;
  
  getFamilyMembers(userId?: string): Promise<FamilyMember[]>;
  createFamilyMember(member: InsertFamilyMember): Promise<FamilyMember>;
  updateFamilyMemberLocation(id: string, lat: number, lon: number): Promise<FamilyMember | undefined>;
  
  getCachedMaps(userId?: string): Promise<CachedMap[]>;
  createCachedMap(map: InsertCachedMap): Promise<CachedMap>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getEmergencyReports(): Promise<EmergencyReport[]> {
    return db.select().from(emergencyReports).orderBy(desc(emergencyReports.createdAt));
  }

  async getEmergencyReport(id: string): Promise<EmergencyReport | undefined> {
    const [report] = await db.select().from(emergencyReports).where(eq(emergencyReports.id, id));
    return report || undefined;
  }

  async createEmergencyReport(report: InsertEmergencyReport): Promise<EmergencyReport> {
    const [created] = await db.insert(emergencyReports).values(report).returning();
    return created;
  }

  async updateEmergencyReportStatus(id: string, status: string): Promise<EmergencyReport | undefined> {
    const [updated] = await db
      .update(emergencyReports)
      .set({ status })
      .where(eq(emergencyReports.id, id))
      .returning();
    return updated || undefined;
  }

  async getFireHotspots(): Promise<FireHotspot[]> {
    return db.select().from(fireHotspots).orderBy(desc(fireHotspots.detectedAt));
  }

  async getActiveFireHotspots(): Promise<FireHotspot[]> {
    return db.select().from(fireHotspots).where(eq(fireHotspots.isActive, true)).orderBy(desc(fireHotspots.detectedAt));
  }

  async createFireHotspot(hotspot: InsertFireHotspot): Promise<FireHotspot> {
    const [created] = await db.insert(fireHotspots).values(hotspot).returning();
    return created;
  }

  async getVolunteers(): Promise<Volunteer[]> {
    return db.select().from(volunteers).orderBy(desc(volunteers.createdAt));
  }

  async getActiveVolunteers(): Promise<Volunteer[]> {
    return db.select().from(volunteers).where(eq(volunteers.isActive, true)).orderBy(desc(volunteers.createdAt));
  }

  async createVolunteer(volunteer: InsertVolunteer): Promise<Volunteer> {
    const [created] = await db.insert(volunteers).values(volunteer).returning();
    return created;
  }

  async getFamilyMembers(userId?: string): Promise<FamilyMember[]> {
    if (userId) {
      return db.select().from(familyMembers).where(eq(familyMembers.userId, userId));
    }
    return db.select().from(familyMembers);
  }

  async createFamilyMember(member: InsertFamilyMember): Promise<FamilyMember> {
    const [created] = await db.insert(familyMembers).values(member).returning();
    return created;
  }

  async updateFamilyMemberLocation(id: string, lat: number, lon: number): Promise<FamilyMember | undefined> {
    const [updated] = await db
      .update(familyMembers)
      .set({ latitude: lat, longitude: lon, lastUpdated: new Date() })
      .where(eq(familyMembers.id, id))
      .returning();
    return updated || undefined;
  }

  async getCachedMaps(userId?: string): Promise<CachedMap[]> {
    if (userId) {
      return db.select().from(cachedMaps).where(eq(cachedMaps.userId, userId)).orderBy(desc(cachedMaps.createdAt));
    }
    return db.select().from(cachedMaps).orderBy(desc(cachedMaps.createdAt));
  }

  async createCachedMap(map: InsertCachedMap): Promise<CachedMap> {
    const [created] = await db.insert(cachedMaps).values(map).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
