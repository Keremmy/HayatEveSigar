import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertEmergencyReportSchema,
  insertFireHotspotSchema,
  insertVolunteerSchema,
  insertFamilyMemberSchema,
  insertUserSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const validated = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByPhone(validated.phone);
      if (existingUser) {
        return res.json(existingUser);
      }
      const user = await storage.createUser(validated);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  app.get("/api/reports", async (req, res) => {
    try {
      const reports = await storage.getEmergencyReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to get reports" });
    }
  });

  app.get("/api/reports/:id", async (req, res) => {
    try {
      const report = await storage.getEmergencyReport(req.params.id);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to get report" });
    }
  });

  app.post("/api/reports", async (req, res) => {
    try {
      const validated = insertEmergencyReportSchema.parse(req.body);
      const report = await storage.createEmergencyReport(validated);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create report" });
    }
  });

  app.patch("/api/reports/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status || typeof status !== "string") {
        return res.status(400).json({ error: "Status is required" });
      }
      const report = await storage.updateEmergencyReportStatus(req.params.id, status);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to update report status" });
    }
  });

  app.get("/api/hotspots", async (req, res) => {
    try {
      const activeOnly = req.query.active === "true";
      const hotspots = activeOnly 
        ? await storage.getActiveFireHotspots()
        : await storage.getFireHotspots();
      res.json(hotspots);
    } catch (error) {
      res.status(500).json({ error: "Failed to get hotspots" });
    }
  });

  app.post("/api/hotspots", async (req, res) => {
    try {
      const validated = insertFireHotspotSchema.parse(req.body);
      const hotspot = await storage.createFireHotspot(validated);
      res.status(201).json(hotspot);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create hotspot" });
    }
  });

  app.get("/api/volunteers", async (req, res) => {
    try {
      const activeOnly = req.query.active === "true";
      const volunteerList = activeOnly
        ? await storage.getActiveVolunteers()
        : await storage.getVolunteers();
      res.json(volunteerList);
    } catch (error) {
      res.status(500).json({ error: "Failed to get volunteers" });
    }
  });

  app.post("/api/volunteers", async (req, res) => {
    try {
      const validated = insertVolunteerSchema.parse(req.body);
      const volunteer = await storage.createVolunteer(validated);
      res.status(201).json(volunteer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create volunteer" });
    }
  });

  app.get("/api/family", async (req, res) => {
    try {
      const userId = req.query.userId as string | undefined;
      const members = await storage.getFamilyMembers(userId);
      res.json(members);
    } catch (error) {
      res.status(500).json({ error: "Failed to get family members" });
    }
  });

  app.post("/api/family", async (req, res) => {
    try {
      const validated = insertFamilyMemberSchema.parse(req.body);
      const member = await storage.createFamilyMember(validated);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create family member" });
    }
  });

  app.patch("/api/family/:id/location", async (req, res) => {
    try {
      const { latitude, longitude } = req.body;
      if (typeof latitude !== "number" || typeof longitude !== "number") {
        return res.status(400).json({ error: "Latitude and longitude are required" });
      }
      const member = await storage.updateFamilyMemberLocation(req.params.id, latitude, longitude);
      if (!member) {
        return res.status(404).json({ error: "Family member not found" });
      }
      res.json(member);
    } catch (error) {
      res.status(500).json({ error: "Failed to update location" });
    }
  });

  app.post("/api/seed-hotspots", async (req, res) => {
    try {
      const sampleHotspots = [
        { latitude: 37.0, longitude: 37.5, intensity: 0.8, source: "FIRMS", isActive: true },
        { latitude: 36.8, longitude: 38.2, intensity: 0.5, source: "FIRMS", isActive: true },
        { latitude: 37.2, longitude: 37.8, intensity: 0.65, source: "FIRMS", isActive: true },
        { latitude: 36.5, longitude: 38.0, intensity: 0.4, source: "Satellite", isActive: true },
      ];

      const created = [];
      for (const hotspot of sampleHotspots) {
        const h = await storage.createFireHotspot(hotspot);
        created.push(h);
      }
      res.status(201).json(created);
    } catch (error) {
      res.status(500).json({ error: "Failed to seed hotspots" });
    }
  });

  return httpServer;
}
